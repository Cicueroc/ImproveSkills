public class Ejercicio_For {
    /*
    Para el bucle For, crea una variable numeroFor, esta variable tendrá como valor 0 y su condición será que la
    variable sea igual o menor que 3, se irá incrementando en 1 su valor cada vez que se ejecute y deberá mostrarse
    por pantalla.
     */

    public static void main (String[] args){
        for(int count = 0; count <=3; count = count = count + 1){
        System.out.println(count);
        }
    }


}


