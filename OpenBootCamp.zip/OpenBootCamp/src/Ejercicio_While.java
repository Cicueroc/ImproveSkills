public class Ejercicio_While {

    /*
    Crea un bucle While, este bucle tendrá que tener como condición que la variable numeroWhile sea inferior a 3,
    el bloque de código que tendrá el bucle deberá:
        Incrementar el valor de la variable en uno cada vez que se ejecute.
        Mostrarlo por pantalla cada vez que se ejecute.
     */
public static void main(String[] args){
    int count = -10;

    while(count < 3){
        System.out.println(count);
        count = count + 1;
    }
}
}
