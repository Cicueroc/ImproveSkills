    public class Ejercicio_DoWhile {
    /*
    Para el bucle Do While, deberás crear la misma estructura que en el While, pero solo se debe ejecutar una vez.
     */

        public static void main(String[] args){
            int count = 10;

            do {
                System.out.println(count);
                count = count - count;
            }while(count != 0);
        }
    }