import javax.swing.JOptionPane;

public class Ejercicio_If {
    public static void main(String[] args){
/*
Usando un if, crear una condición que compare si la variable numeroIf es positivo, negativo, o 0.
Pista: Los números inferiores a 0 son negativos y los superiores, positivos.
 */
        int     numeroIf, dato = 0;
        numeroIf = Integer.parseInt(JOptionPane.showInputDialog("Digite un numero: "));
        if(numeroIf == dato){
            JOptionPane.showMessageDialog(null, "El número es igual a 0");
        } else if (numeroIf > 0) {
            JOptionPane.showMessageDialog(null, "El número es Positivo");
        } else {
            JOptionPane.showMessageDialog(null, "El número es Negativo");
        }
    }
}
